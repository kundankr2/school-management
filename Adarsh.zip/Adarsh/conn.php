<?php
$conn= mysqli_connect("localhost:3307", "root", "", "school");
if($conn)
echo "hello";
else
echo "not hello";
?>